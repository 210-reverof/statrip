package user;
import java.sql.SQLException;
import java.util.List;

public interface FollowDao {
	void follow(String myId, String otherId) throws SQLException;
	void unfollow(String myId, String otherId) throws SQLException;
	List<UserDto> myFollowings(String userId) throws SQLException;
	List<UserDto> myFollowers(String userId) throws SQLException;
}

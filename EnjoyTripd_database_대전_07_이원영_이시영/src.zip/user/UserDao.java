package user;
import java.sql.SQLException;

public interface UserDao {
	void join(UserDto userDto) throws SQLException;
	void update(UserDto userDto) throws SQLException;
	void deleteUSer(String userId) throws SQLException;
	UserDto myInfo(String userId) throws SQLException;
}

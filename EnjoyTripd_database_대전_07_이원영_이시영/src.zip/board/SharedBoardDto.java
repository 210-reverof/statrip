package board;

import java.time.LocalDateTime;

public class SharedBoardDto extends BoardDto{
	private int shareArticle;
	private String userId;
	private String routeId;
	private String title;
	private String content;
	private LocalDateTime createTime;
	private int like;
	private int hit;
	
	public int getShareArticle() {
		return shareArticle;
	}
	public void setShareArticle(int shareArticle) {
		this.shareArticle = shareArticle;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getRouteId() {
		return routeId;
	}
	public void setRouteId(String routeId) {
		this.routeId = routeId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public LocalDateTime getCreateTime() {
		return createTime;
	}
	public void setCreateTime(LocalDateTime createTime) {
		this.createTime = createTime;
	}
	public int getLike() {
		return like;
	}
	public void setLike(int like) {
		this.like = like;
	}
	public int getHit() {
		return hit;
	}
	public void setHit(int hit) {
		this.hit = hit;
	}
	
	@Override
	public String toString() {
		return "shareArticle=" + shareArticle + ", userId=" + userId + ", routeId=" + routeId
				+ ", title=" + title + ", content=" + content + ", createTime=" + createTime + ", like=" + like
				+ ", hit=" + hit;
	}
}

package board;

public class SharedCommentDto extends CommentDto{
	private int SharedArticleId;

	public SharedCommentDto(int sharedArticleId) {
		super();
		SharedArticleId = sharedArticleId;
	}

	public int getSharedArticleId() {
		return SharedArticleId;
	}

	public void setSharedArticleId(int sharedArticleId) {
		SharedArticleId = sharedArticleId;
	}
}

package board;

import java.time.LocalDateTime;

public class CommentDto {
	private int articleId;
	private int commentId;
	private int userId;
	private String content;
	private LocalDateTime createdTime;
	
	public CommentDto() {}

	public CommentDto(int articleId, int commentId, int userId, String content, LocalDateTime createdTime) {
		super();
		this.articleId = articleId;
		this.commentId = commentId;
		this.userId = userId;
		this.content = content;
		this.createdTime = createdTime;
	}

	public int getArticleId() {
		return articleId;
	}

	public void setArticleId(int articleId) {
		this.articleId = articleId;
	}

	public int getCommentId() {
		return commentId;
	}

	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public LocalDateTime getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(LocalDateTime createdTime) {
		this.createdTime = createdTime;
	}

}

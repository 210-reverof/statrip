package board;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public interface CommentDao {
	int writeComment(BoardDto boardDto, CommentDto commentDto) throws SQLException;
	List<CommentDto> listComment(Map<String, String> map) throws SQLException;
	int totalCommentCount(Map<String, String> map) throws SQLException;
	void deleteComment(int commentId) throws SQLException;
}

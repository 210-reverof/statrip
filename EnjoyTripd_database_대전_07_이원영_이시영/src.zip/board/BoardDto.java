package board;

import java.time.LocalDateTime;

public class BoardDto {
	private int articleId;
	private String userId;
	private String routeId;
	private String title;
	private String content;
	private LocalDateTime createTime;
	private int like;
	private int hit;
	
	public BoardDto() {}

	public BoardDto(int articleId, String userId, String routeId, String title, String content,
			LocalDateTime createTime, int like, int hit) {
		super();
		this.articleId = articleId;
		this.userId = userId;
		this.routeId = routeId;
		this.title = title;
		this.content = content;
		this.createTime = createTime;
		this.like = like;
		this.hit = hit;
	}

	public int getArticleId() {
		return articleId;
	}

	public void setArticleId(int articleId) {
		this.articleId = articleId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getRouteId() {
		return routeId;
	}

	public void setRouteId(String routeId) {
		this.routeId = routeId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public LocalDateTime getCreateTime() {
		return createTime;
	}

	public void setCreateTime(LocalDateTime createTime) {
		this.createTime = createTime;
	}

	public int getLike() {
		return like;
	}

	public void setLike(int like) {
		this.like = like;
	}

	public int getHit() {
		return hit;
	}

	public void setHit(int hit) {
		this.hit = hit;
	}
}

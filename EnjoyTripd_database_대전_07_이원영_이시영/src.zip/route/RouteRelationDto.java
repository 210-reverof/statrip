package route;

public class RouteRelationDto {
	int routeId;
	int attractionId;
	int order;
	boolean visited;
	
	public RouteRelationDto(int routeId, int attractionId, int order, boolean visited) {
		super();
		this.routeId = routeId;
		this.attractionId = attractionId;
		this.order = order;
		this.visited = visited;
	}

	public int getRouteId() {
		return routeId;
	}

	public void setRouteId(int routeId) {
		this.routeId = routeId;
	}

	public int getAttractionId() {
		return attractionId;
	}

	public void setAttractionId(int attractionId) {
		this.attractionId = attractionId;
	}

	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	public boolean isVisited() {
		return visited;
	}

	public void setVisited(boolean visited) {
		this.visited = visited;
	}
	
	
	
	
}

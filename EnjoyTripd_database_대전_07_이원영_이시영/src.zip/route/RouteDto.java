package route;

public class RouteDto {
	int routeId;
	String userId;
	
	public RouteDto(int routeId, String userId) {
		this.routeId = routeId;
		this.userId = userId;
	}

	public int getRouteId() {
		return routeId;
	}

	public void setRouteId(int routeId) {
		this.routeId = routeId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	
	
	
}

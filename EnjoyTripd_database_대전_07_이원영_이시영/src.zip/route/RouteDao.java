package route;
import java.sql.SQLException;
import java.util.List;

import attraction.AttractionDto;

public interface RouteDao {
	void addRoute(String userId, List<Integer> attractions) throws SQLException;
	void updateRoute(RouteDto routeDto, List<Integer> attractions) throws SQLException;
	void deleteRoute(RouteDto routeDto) throws SQLException;
	List<RouteDto> getMyRoutes(String userId) throws SQLException;
	List<AttractionDto> getAttrs(RouteDto routeDto) throws SQLException;
}

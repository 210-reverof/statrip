package attraction;


public class AttractionDto {
	int contentId;
	String title;
	String addr;
	String firstImage;
	double latitude;
	double longitude;
	
	public AttractionDto(int contentId, String title, String addr, String firstImage, double latitude, double longitude) {
		super();
		this.contentId = contentId;
		this.title = title;
		this.addr = addr;
		this.firstImage = firstImage;
		this.latitude = latitude;
		this.longitude = longitude;
	}

	public int getContentId() {
		return contentId;
	}

	public void setContentId(int contentId) {
		this.contentId = contentId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

	public String getFirstImage() {
		return firstImage;
	}

	public void setFirstImage(String firstImage) {
		this.firstImage = firstImage;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	
	
}
